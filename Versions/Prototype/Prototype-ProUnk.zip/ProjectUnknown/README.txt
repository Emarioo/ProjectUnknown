Warning:
- The .exe is for Windows.
- Windows and your web browser will most likely warn you about the
  game being a virus. It is not. But there may be bugs like memory leaks.

Note:
- F3 to bring up FPS. Up/Down arrow to zoom in/out. Left/Right arrows to move
  horizontally.
- F2 to see multiplayer information.

Notes 2:
This is a prototype. It will have bugs and no guarrantees are made.

You can enter the text below in a terminal if you want
to start to game instances at once and have them
automatically connect to each other.

> projectunknown.exe --server --client 127.0.0.1
